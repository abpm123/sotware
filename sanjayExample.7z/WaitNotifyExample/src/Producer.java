
public class Producer implements Runnable {

	WareHouse wareHouse;
	
	
	public Producer(WareHouse wareHouse) {
		super();
		this.wareHouse = wareHouse;
	}


	@Override
	public void run() {
		
		while(true)
		{
			int num = (int)(Math.random());
			
			wareHouse.addItem(num);
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}

	}

}
