class ParentServer
{
	void show()throws InsufficientBalanceException
	{
		
	}
}
public class Server extends ParentServer {
	
	void show() throws InsufficientBalanceException
	{
		try
		{
		throw new InvalidAccountNumberException("invalid account number");
		}catch(InvalidAccountNumberException ian)
		{
			throw new InsufficientBalanceException(ian.getMessage());
		}
	}

}
