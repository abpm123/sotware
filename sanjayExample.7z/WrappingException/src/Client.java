
public class Client {

	public static void main(String[] args) {
		
		
		// all exceptions need to handle in main
		
		try
		{
			Server s=new Server();
			
			s.show();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
