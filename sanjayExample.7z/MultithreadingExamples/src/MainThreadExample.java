class MyThread extends Thread
{
	Thread t;
	MyThread(Thread t)
	{
		this.t=t;
	}
	public void run()
	{
		try {
			t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(int i=1;i<=5;i++)
		System.out.println("From child thread");
	}
	
	
}


public class MainThreadExample {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getName());
		
		MyThread m=new MyThread(Thread.currentThread());
		
		m.start();
		/*
		try {
			m.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		Thread.sleep(500);
		
		System.out.println("From main thread last line");
	}

}
