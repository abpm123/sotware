import static java.lang.System.*;//1.5
class Super {
public int a;
 protected Super(int a) { this.a = a; }
}

 class Sub extends Super {
 public Sub(int a) { super(a); }
public Sub() {
	super();
	this.a = 5; }
 }


public class Test {

	public static void main(String[] args) {
		out.println("Test");
	}

}
