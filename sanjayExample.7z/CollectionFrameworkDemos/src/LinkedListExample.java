import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListExample {

	public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<>();
		
		l.add(3);//autoboxing
		
		l.add(3);
		
		l.add(4);
		
		System.out.println(l);
		
		//2
		
		for(int i=0;i<l.size();i++)
		{
			System.out.println(l.get(i));
		}
		
		//3
		for(Integer i:l)
		{
			System.out.println(i);
		}
		
		//4
		Iterator it = l.iterator();  //forward
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		//5
		ListIterator lit = l.listIterator();//forward and backward
		
		while(lit.hasNext())
		{
			System.out.println(lit.next());
		}

	}

}
