import java.util.HashSet;
class Employee 
{
	private String name;

	public Employee(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + "]";
	}

	public int hashCode()
	{
		System.out.println("from hashcode");
		return 420;
	}
	
	public boolean equals(Object obj)
	{
		System.out.println("From equals");
		Employee emp = (Employee)obj;
		
		if(name.equals(emp.name))
		{
			return true;
		}
		
		else
			return false;
	}
	
	
}
public class HashSetExample {

	public static void main(String[] args) {
		HashSet hs=new HashSet();
		
		hs.add(new Employee("Sachin"));
		hs.add(new Employee("Sachin"));
		
		System.out.println(hs);

	}

}
