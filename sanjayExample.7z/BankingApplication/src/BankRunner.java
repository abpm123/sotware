
public class BankRunner implements Runnable {

	ICICIBank bank;
	
	
	public BankRunner(ICICIBank bank) {
		super();
		this.bank = bank;
	}


	@Override
	public void run() {
		
		try
		{
			if(Thread.currentThread().getName().equals("first"))
			{
				System.out.println("Balance = "+bank.withdrawAmount(101, 2000));
			}
			else
			{
				System.out.println("Balance = "+bank.withdrawAmount(101, 2000));
			}	
		}catch(InvalidAccountNumberException iane)
		{
			System.out.println("invalid account number");
		}catch(InsufficientBalanceException ibe)
		{
			System.out.println("Insufficient balance");
		}

	}

}
